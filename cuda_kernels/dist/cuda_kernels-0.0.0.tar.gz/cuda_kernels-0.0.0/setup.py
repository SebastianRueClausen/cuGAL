from setuptools import setup

setup(
    name='cuda_kernels',
    version='0.0.0',
)